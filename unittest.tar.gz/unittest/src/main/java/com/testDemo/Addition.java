package com.testDemo;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.List;

public class Addition {
    public static void main(String[] args) {
        System.out.println("This is about adding 2 integers");
        int a=10;
        int b=20;
        int sum=a+b;
        System.out.println(sum);
    }

    public int sum(int a, int b){
        return a+b;

    }

   public String sum(String fname,String lname){
        return fname+lname;
    }

   public List sum(List listA, List listB){
        List list=new ArrayList();
        list.add(listA);
        list.add(listB);
        return list;

    }

    public Integer sum(Integer a,Integer b){
        return a+b;
    }

    float sum(float a,float b){
        return a+b;
    }



}
