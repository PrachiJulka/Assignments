package com.testDemo;

public class Subtraction {
    public static void main(String[] args) {
        System.out.println("This is about subtracting 2 integers");
        int a=10;
        int b=20;
        int sum=a-b;
        System.out.println(sum);
    }

    int sub(int a,int b){
        return a-b;
    }

    float sub(float a,float b){
        return a-b;
    }
}
