package com.testDemo

import org.junit.Ignore
import spock.lang.Specification


class SubtractionSpec extends Specification {

    Subtraction subtraction;

    void setup(){
        subtraction= new Subtraction();
    }
    @Ignore
    def "Sub of Integers"() {
        given:
        int a=30
        int b=20

        expect:
        subtraction.sub(a,b)
    }

    def "Sub of float"() {

        given:
        float a=3.0f
        float b=2.0f

        expect:
        subtraction.sub(a,b)


    }
}
