package com.testDemo

import spock.lang.Specification

class Q3Test extends Specification {

  Q3 q3=new Q3();

    def "When divided by zero Exception is raised"() {
        given:
        int a=0;
        int b=2;

        when:
        q3.divide(b,0)

        then:
        thrown(ArithmeticException)

    }
}
