package com;


import com.testDemo.Addition;
import junit.framework.TestCase;
import org.junit.Assert;
import org.junit.Test;

public class AdditionTest extends TestCase {

    private Addition addition=new Addition();

    @Test
    public void canaryTest(){
        Assert.assertTrue(true);
    }

    @Test
    public void testInteger(){
        Assert.assertEquals(addition.sum(1,1),2);
    }

    @Test
    public void testString(){
        Assert.assertEquals(addition.sum("Prachi","Julka"),"PrachiJulka");
    }
}
