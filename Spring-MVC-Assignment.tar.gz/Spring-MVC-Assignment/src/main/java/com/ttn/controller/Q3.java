package com.ttn.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

/**
 * Use annotation in StudentController to define a default action index which renders a jsp page.
 */
@Controller
public class Q3 {

    @RequestMapping(value = "/Q3", method = RequestMethod.GET)
    public ModelAndView printWelcome() {
        ModelAndView model=new ModelAndView();
        model.setViewName("Q3");
        return model;
    }

}
