package com.ttn.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Q1. Implement AbstractController in StudentController. create a mapping index.html for it and render index.jsp view from it which displays messages "Hello from index.gsp".
 */
/*@Controller*/
public class Q1StudentController extends AbstractController {
    /*Q1 */
    @Override
    protected ModelAndView handleRequestInternal(HttpServletRequest request,
                                                 HttpServletResponse response) throws Exception {
        ModelAndView modelAndView = new ModelAndView("index");
        modelAndView.addObject("msg", "Hello from index.jsp");
        return modelAndView;
    }
}

