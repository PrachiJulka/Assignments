package com.ttn.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.util.Map;

/**
 *Q7 Now place both the arguments inside a Map and access the Map instead.(Hint : check the slide for @PathVariable action returnCountryAndState  shows how to do it with map)
  Q8 Use @RequestParam annotation to access the firstname and lastname in formData action of StudentController.
 */
@Controller
public class Q7StudentController {
    /*Q7*/
    @RequestMapping(value = "/index7/{firstName}/{secondName}", method = RequestMethod.GET)
    public ModelAndView path(@PathVariable Map<String, String> requestMap) {

        ModelAndView model = new ModelAndView();
        model.setViewName("Q6");
        String fname=requestMap.get("firstName");
        String lname=requestMap.get("secondName");
        model.addObject("msg", fname);
        model.addObject("msg1",lname);
        return model;
    }

   /* Q8*/
   @RequestMapping(value = "/Q8", method = RequestMethod.GET)
    ModelAndView submitForm() {
       ModelAndView model=new ModelAndView();
        model.setViewName("Q8");
       return model;
   }
   @RequestMapping(value = "/Q8demo", method = RequestMethod.POST)
  @ResponseBody
   String submitForm(@RequestParam("firstName") String firstName,
                     @RequestParam("lastName") String lastName) {
       return "FirstName: " + firstName+ " LastName: " + lastName;
   }
}
