package com.ttn.controller;

import com.ttn.domains.StudentCO;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Q9 Create a StudentCO and bind firstname and lastname with instance variable of StudentCO.
 */
@Controller
public class Q9StudentController {

    @RequestMapping(value = "/Q9", method = RequestMethod.GET)
    String submitForm() {
        return "Q9";
    }
    @RequestMapping(value = "/Q9demo", method = RequestMethod.POST)
    @ResponseBody
    String submitForm(StudentCO studentCO) {
        return "FirstName:" + studentCO.getFirstName() + " SecondName:" + studentCO.getLastName();
    }

}
