package com.ttn.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

/**
 * Q4 Create one more annotation based action hello inside the StudentController which and use @ResponseBody annotation from it to display Hello world.
   Q5 Create one more action which sends Model HelloWorld to the jsp file.
 */
@Controller
public class Q4StudentController {

    @RequestMapping(value = "/Q4", method = RequestMethod.GET)
    public ModelAndView printWelcome() {
        ModelAndView model=new ModelAndView();
        model.setViewName("Q4");
        return model;
    }

    /*Q4*/
    @RequestMapping(value = "/hello1", method = RequestMethod.GET)
    @ResponseBody
    public String print() {

        return "HelloWorld";

    }
    /*Q5*/
    @ResponseBody
    @RequestMapping("/Q5")
    ModelAndView index() {
        ModelAndView modelAndView = new ModelAndView("Q5");
        modelAndView.addObject("msg", "Hello World");
        return modelAndView;
    }
}
