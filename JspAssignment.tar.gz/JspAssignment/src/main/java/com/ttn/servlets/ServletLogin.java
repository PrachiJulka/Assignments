package com.ttn.servlets;

import com.ttn.dao.impl.UserDaoImplementation;
import com.ttn.domains.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;

@WebServlet(name = "ServletLogin",urlPatterns = "/login")
public class ServletLogin extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
           String email = request.getParameter("loginEmail");
            String password = request.getParameter("password");
            User user = new UserDaoImplementation().validateUser(email, password);
            if (user != null) {
                HttpSession session = request.getSession(true);
                session.setAttribute("user", user);
                response.sendRedirect("welcomePage.jsp");
            }
            else {
                response.sendRedirect("Q3.jsp?msg=Email or Password is invalid");
            }
        }
    }



