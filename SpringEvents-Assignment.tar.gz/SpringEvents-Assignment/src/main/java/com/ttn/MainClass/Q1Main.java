package com.ttn.MainClass;

import com.ttn.customEvents.asynchronousEvent.CustomPublisherQ1;
import com.ttn.customEvents.synchronousEvent.CustomEvent;
import com.ttn.dao.impl.EmployeeDaoImplementation;
import com.ttn.domains.Employee;
import com.ttn.springConfig.JavaConfigAsynchronousEvent;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.Scanner;

public class Q1Main {


    public static void main(String[] args) {
         AnnotationConfigApplicationContext applicationContext=new AnnotationConfigApplicationContext(JavaConfigAsynchronousEvent.class);
        EmployeeDaoImplementation employeeDaoImplementation=applicationContext.getBean(EmployeeDaoImplementation.class);
       // applicationContext.start();

        CustomPublisherQ1 publisher= applicationContext.getBean(CustomPublisherQ1.class);
        Scanner sc=new Scanner(System.in);
        int c;

        while(true) {
            System.out.println("Enter 1 to add Employee");
            System.out.println("Enter 0 to exit");
            c=sc.nextInt();
            switch (c){
                case 1:Q1Main.add(employeeDaoImplementation,sc,publisher);
                    break;
                case 0: System.exit(0);
                    break;
                    default:
                        System.out.println("Please Enter Correct Input");
                        break;
            }
           //1 applicationContext.stop();

        }

    }

    static public void add(EmployeeDaoImplementation employeeDaoImplementation,Scanner sc,CustomPublisherQ1 customPublisherQ1){
        Employee employee = new Employee();
        System.out.println("Enter Employee Name");
        employee.setName(sc.next());
        System.out.println("Enter Employee Salary");

        Long salary=sc.nextLong();
        employee.setSalary(salary);
        employeeDaoImplementation.addUser(employee);
        if (salary>30000){
            System.out.println("hey");
            CustomEvent customEvent =new CustomEvent(employee);
            customPublisherQ1.publish(customEvent);
            }
    }
}
