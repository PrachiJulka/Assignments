package com.ttn.MainClass;

import com.ttn.customEvents.synchronousEvent.ChangePinEvent;
import com.ttn.customEvents.synchronousEvent.MobileNumberAlertEvent;
import com.ttn.customEvents.synchronousEvent.WithdrawAlertEvent;
import com.ttn.dao.impl.AtmDao;
import com.ttn.dao.impl.AtmDaoImplementation;
import com.ttn.domains.Atm;
import com.ttn.springConfig.JavaConfig;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.util.Scanner;

public class Q2Main {

    public static void main(String[] args) {
        AnnotationConfigApplicationContext applicationContext=new AnnotationConfigApplicationContext(JavaConfig.class);
        AtmDao atmDao=applicationContext.getBean(AtmDaoImplementation.class);
       // applicationContext.start();
        MobileNumberAlertEvent mobileNumberAlertEvent= applicationContext.getBean(MobileNumberAlertEvent.class);
        WithdrawAlertEvent withdrawAlertEvent=applicationContext.getBean(WithdrawAlertEvent.class);
        ChangePinEvent changePinEvent=applicationContext.getBean(ChangePinEvent.class);
        Scanner sc=new Scanner(System.in);
        Atm atm= new Atm();
        int c;

        while(true){

            System.out.println("Enter 1 to withdraw Money");
            System.out.println("Enter 2 to change pin");
            System.out.println("Enter 3 to change mobile number");
            System.out.println("Enter 4 to exit");
            c=sc.nextInt();

            switch (c){
                case 1:withDraw(sc,atmDao,atm,withdrawAlertEvent);
                break;
                case 2:changePin(sc,atmDao,atm,changePinEvent);
                break;
                case 3:changeMobile(sc,atmDao,atm,mobileNumberAlertEvent);
                break;
                case 4:System.exit(0);
                break;
                default:
                    System.out.println("Please Enter correct value");
            }



        }

    }

//a
    static void withDraw(Scanner sc,AtmDao atmDao,Atm atm,WithdrawAlertEvent withdrawAlertEvent){
        System.out.println("Enter Card Number:");
        atm.setCardNumber(sc.nextInt());
        System.out.println("Enter amount to debit");
        Long amount=sc.nextLong();
        System.out.println(amount);
        atm.setDebitedmoney(amount);
        atmDao.withdrawMoney(atm,amount);

        withdrawAlertEvent.alertWithdraw();

    }

//b
    static void changePin(Scanner sc, AtmDao atmDao, Atm atm, ChangePinEvent changePinEvent){
        System.out.println("Enter Card Number:");
        atm.setCardNumber(sc.nextInt());
        System.out.println("Enter Pin to change");
        Integer change=sc.nextInt();
        atmDao.changePin(atm,change);
        changePinEvent.alertTochangePin();

    }

    static void changeMobile(Scanner sc, AtmDao atmDao, Atm atm,MobileNumberAlertEvent mobileNumberAlertEvent){
        System.out.println("Enter Card Number:");
       // atm.setAtmId(sc.nextInt());
        System.out.println("Enter Pin to change");
        Integer change=sc.nextInt();
        atmDao.changeMobileNumber(atm,change);
        mobileNumberAlertEvent.alertMobileUpdate();

    }
}
