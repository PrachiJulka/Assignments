package com.ttn.domains;


import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Atm {

    @Id
    private  long cardNumber;
    private int pin;
    private long Debitedmoney;
    private int mobileNumber;


    public long getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(long cardNumber) {
        this.cardNumber = cardNumber;
    }

    public int getPin() {
        return pin;
    }

    public void setPin(int pin) {
        this.pin = pin;
    }

    public long getDebitedmoney() {
        return Debitedmoney;
    }

    public void setDebitedmoney(long debitedmoney) {
        Debitedmoney = debitedmoney;
    }

    public int getMobileNumber() {
        return mobileNumber;
    }

    public void setMobileNumber(int mobileNumber) {
        this.mobileNumber = mobileNumber;
    }




}
