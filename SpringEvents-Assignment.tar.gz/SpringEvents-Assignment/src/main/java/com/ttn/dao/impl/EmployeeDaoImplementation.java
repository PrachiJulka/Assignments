package com.ttn.dao.impl;


import com.ttn.domains.Employee;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class EmployeeDaoImplementation implements EmployeeDao {

    @Autowired
    SessionFactory sessionFactory;

    @Override
    public void addUser(Employee employee) {


        final Session session = sessionFactory.openSession();
        try {
            session.beginTransaction();
            session.save(employee);
            session.getTransaction().commit();
        } catch (final Exception e) {
        } finally {
            session.close();
        }



    }

    @Override
    public void withdrawMoney(Employee employee) {
       /* System.out.println("in");
        final Session session = sessionFactory.openSession();
        try {
            session.beginTransaction();
            Query amount= session.createQuery("select * from Employee where name=?");
            amount.setParameter(0,employee.getName());
           // amount.getFirstResult();
            System.out.println(amount.getFirstResult());
            Long amountToAdd=(Long) employee.getSalary()+amount.getFirstResult();
            System.out.println(amountToAdd);
            employee.setSalary(amountToAdd);
            session.update(employee);
            session.getTransaction().commit();
        } catch (final Exception e) {
        } finally {
            session.close();
        }*/
    }
}
