package com.ttn.dao.impl;

import com.ttn.domains.Atm;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import javax.persistence.Query;



@Repository
public class AtmDaoImplementation implements AtmDao {



    @Autowired
    SessionFactory sessionFactory;


    @Override
    public boolean withdrawMoney(Atm atm,long withdrawAmount) {
        Session session = sessionFactory.openSession();
        try {
            System.out.println("hihih");
            session.beginTransaction();
            System.out.println("hihihi1");
            Query amount= session.createQuery("select Debitedmoney from Atm where cardNumber="+atm.getCardNumber());
            System.out.println("hihihi2");
           // amount.setParameter(0,atm.getCardNumber());
            System.out.println("kikikik");
            // amount.getFirstResult();
            System.out.println(amount.getSingleResult());
            Long accnt=(Long) amount.getSingleResult();
            System.out.println(amount.getSingleResult());
            Long amountLeft=(Long) (accnt-withdrawAmount);
            System.out.println(amountLeft);
            atm.setDebitedmoney(amountLeft);
            session.update(atm);
            session.getTransaction().commit();
        } catch (final Exception e) {
        } finally {
            session.close();
        }
        return false;
    }

    @Override
    public boolean changePin(Atm atm,int pin) {
        Session session = sessionFactory.openSession();
        try {
            session.beginTransaction();
            Query query= session.createQuery(" from Atm where cardNumber="+atm.getCardNumber());
            atm.setPin(pin);
            session.update(atm);
            session.getTransaction().commit();

        } catch (final Exception e) {
        } finally {
            session.close();
        }
        return false;


    }

    @Override
    public boolean changeMobileNumber(Atm atm,int mobileNumber) {
        Session session = sessionFactory.openSession();
        try {
            session.beginTransaction();
            Query query=(Query) session.createQuery(" from Atm where cardNumber="+atm.getCardNumber());
           atm.setMobileNumber(mobileNumber);
            session.update(atm);
            session.getTransaction().commit();

        } catch (final Exception e) {
        } finally {
            session.close();
        }

return true;
    }
}
