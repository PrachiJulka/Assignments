package com.ttn.dao.impl;

import com.ttn.domains.Atm;

public interface AtmDao {
    public boolean withdrawMoney(Atm atm,long withdrawAmount);
    public boolean changePin(Atm atm,int pin);
    public boolean changeMobileNumber(Atm atm,int MobileNumber);
}

