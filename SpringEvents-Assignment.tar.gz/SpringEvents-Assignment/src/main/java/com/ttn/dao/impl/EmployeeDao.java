package com.ttn.dao.impl;

import com.ttn.domains.Employee;


public interface EmployeeDao {


    public void addUser(Employee employee);
    public void withdrawMoney(Employee employee);
}
