package com.ttn.springConfig;


import com.ttn.dao.impl.AtmDaoImplementation;
import org.hibernate.SessionFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.orm.hibernate4.LocalSessionFactoryBean;

import javax.sql.DataSource;
import java.util.Properties;

@ComponentScan("com.ttn.customEvents.synchronousEvent")
@Configuration
public class JavaConfig {


    @Bean
    public DataSource getDataSource() {
        final DriverManagerDataSource ds = new DriverManagerDataSource();
        ds.setDriverClassName("com.mysql.jdbc.Driver");
        ds.setUrl("jdbc:mysql://localhost:3306/EventsAndIntegration");
        ds.setUsername("root");
        ds.setPassword("root");
        return ds;
    }

    @Bean
    public LocalSessionFactoryBean getSessionFactory() {

        final LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
        sessionFactory.setDataSource(getDataSource());
        sessionFactory.setPackagesToScan(new String[] { "com.ttn.domains"});
        sessionFactory.setHibernateProperties(getHibernateProperties());
        return sessionFactory;

    }

    @Bean
    public Properties getHibernateProperties() {
        final Properties properties = new Properties();
        properties.put("hibernate.dialect", "org.hibernate.dialect.MySQL5Dialect");
        properties.put("hibernate.show_sql", "true");
        properties.put("hibernate.hbm2ddl.auto", "update");

        return properties;
    }

    @Bean
    public HibernateTransactionManager transactionManager(SessionFactory s) {
        final HibernateTransactionManager txManager = new HibernateTransactionManager();
        txManager.setSessionFactory(s);
        return txManager;
    }

/*
    @Bean
    public WithdrawAlertEvent withdrawAlertListener(){
        final WithdrawAlertEvent withdrawAlertListener=new WithdrawAlertEvent();
        return withdrawAlertListener;
    }

        @Bean
    public ChangePinEvent changePinEvent(){
        final ChangePinEvent changePinEvent=new ChangePinEvent();
        return changePinEvent;
        }

        @Bean
        public MobileNumberAlertEvent mobileNumberAlertEvent(){
        final MobileNumberAlertEvent mobileNumberAlertEvent=new MobileNumberAlertEvent();
        return mobileNumberAlertEvent;
        }*/

        @Bean
        public AtmDaoImplementation atmDaoImplementation(){
        final AtmDaoImplementation atmDaoImplementation=new AtmDaoImplementation();
        return atmDaoImplementation;
        }
}
