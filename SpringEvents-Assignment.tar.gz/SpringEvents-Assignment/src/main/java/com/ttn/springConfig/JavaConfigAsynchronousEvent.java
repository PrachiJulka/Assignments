package com.ttn.springConfig;

import com.ttn.customEvents.asynchronousEvent.AsynchronousEventQ1;
import com.ttn.customEvents.asynchronousEvent.SalaryAlertListener;
import com.ttn.dao.impl.EmployeeDaoImplementation;
import org.hibernate.SessionFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate4.HibernateTransactionManager;
import org.springframework.orm.hibernate4.LocalSessionFactoryBean;

import javax.sql.DataSource;
import java.util.Properties;

/*@EnableTransactionManagement*/

@ComponentScan("com.ttn.customEvents.asynchronousEvent")
@Configuration
public class JavaConfigAsynchronousEvent {

    @Bean
    public DataSource getDataSource() {
        final DriverManagerDataSource ds = new DriverManagerDataSource();
        ds.setDriverClassName("com.mysql.jdbc.Driver");
        ds.setUrl("jdbc:mysql://localhost:3306/EventsAndIntegration");
        ds.setUsername("root");
        ds.setPassword("root");
        return ds;
    }

    @Bean
    public LocalSessionFactoryBean getSessionFactory() {

        final LocalSessionFactoryBean sessionFactory = new LocalSessionFactoryBean();
        sessionFactory.setDataSource(getDataSource());
        sessionFactory.setPackagesToScan(new String[] { "com.ttn.domains"});
        sessionFactory.setHibernateProperties(getHibernateProperties());
        return sessionFactory;

    }

    @Bean
    public Properties getHibernateProperties() {
        final Properties properties = new Properties();
        properties.put("hibernate.dialect", "org.hibernate.dialect.MySQL5Dialect");
        properties.put("hibernate.show_sql", "true");
        properties.put("hibernate.hbm2ddl.auto", "update");

        return properties;
    }

    @Bean
    public HibernateTransactionManager transactionManager(SessionFactory s) {
        final HibernateTransactionManager txManager = new HibernateTransactionManager();
        txManager.setSessionFactory(s);
        return txManager;
    }

    @Bean
    public SalaryAlertListener salaryAlertListener(){
        final SalaryAlertListener salaryAlertListener1=new SalaryAlertListener();
       return salaryAlertListener1;
    }

    @Bean
    public AsynchronousEventQ1 asynchronousEventQ1(){
        final AsynchronousEventQ1 asynchronousEventQ11=new AsynchronousEventQ1();
        return asynchronousEventQ11;
    }
    @Bean
    public EmployeeDaoImplementation employeeDaoImplementation(){
        final EmployeeDaoImplementation employeeDaoImplementation=new EmployeeDaoImplementation();
        return employeeDaoImplementation;
    }
    /*@Bean
    public CustomPublisherQ1 customPublisherQ1(){
       final CustomPublisherQ1 customPublisherQ1=new CustomPublisherQ1();
        return customPublisherQ1;
    }*/
}
