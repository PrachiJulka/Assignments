package com.ttn.customEvents.synchronousEvent;

import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

@Component
public class AtmListener implements ApplicationListener<CustomEvent> {


    @Override
    public void onApplicationEvent(CustomEvent event) {
         System.out.println("hq"+event.getSource());
        }



}
