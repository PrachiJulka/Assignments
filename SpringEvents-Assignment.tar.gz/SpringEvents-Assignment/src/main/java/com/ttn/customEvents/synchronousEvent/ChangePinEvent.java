package com.ttn.customEvents.synchronousEvent;

import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.stereotype.Component;

@Component
public class ChangePinEvent  implements ApplicationEventPublisherAware {

        private ApplicationEventPublisher applicationEventPublisher;

        public void alertTochangePin() {
        CustomEvent customEvent = new CustomEvent(this);
        applicationEventPublisher.publishEvent(customEvent);
    }
        @Override
        public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
        this.applicationEventPublisher = applicationEventPublisher;
    }

        public String toString(){
        return "Pin Updated";
    }

    }
