package com.ttn.customEvents.asynchronousEvent;

import com.ttn.customEvents.synchronousEvent.CustomEvent;
import com.ttn.domains.Employee;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;


@Component
public class SalaryAlertListener implements ApplicationListener<CustomEvent> {
    @Override
    public void onApplicationEvent(CustomEvent event) {
        if(event.getSource() instanceof Employee){
            Employee employee= (Employee) event.getSource();
            System.out.println("Employee: "+ employee.getName()+"\n Salary: "+employee.getSalary()
                    );

            try {
                Thread.sleep(1000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("Salary is greater tha 30000");
        }
        else{
            System.out.println("hq"+event.getSource());
        }


    }


}
