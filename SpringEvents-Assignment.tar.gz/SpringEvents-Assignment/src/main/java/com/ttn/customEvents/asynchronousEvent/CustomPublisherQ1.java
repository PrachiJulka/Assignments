package com.ttn.customEvents.asynchronousEvent;

import com.ttn.customEvents.synchronousEvent.CustomEvent;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;
import org.springframework.stereotype.Component;

@Component
public class CustomPublisherQ1 implements ApplicationEventPublisherAware {

    private ApplicationEventPublisher publisher;
    @Override
    public void setApplicationEventPublisher(ApplicationEventPublisher applicationEventPublisher) {
        System.out.println("Application event Publisher is set to Custom Publisher");
        publisher=applicationEventPublisher;
    }

    public void publish(CustomEvent event){
        System.out.println("from publish");
        publisher.publishEvent(event);
    }
}
