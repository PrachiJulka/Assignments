package ttn.com.execute;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import ttn.com.domains.Complex;

public class Question5 {

    public static void main(String[] args) {
        ApplicationContext applicationContext=new ClassPathXmlApplicationContext("Question5SpringConfig.xml");
       Complex complex= applicationContext.getBean("complexBean", Complex.class);
        System.out.println("---------------List-------------");
        System.out.println(complex.getList());
        System.out.println("---------------Set--------------");
        System.out.println(complex.getSet());
        System.out.println("---------------Map--------------");
        System.out.println(complex.getMap());



    }
}
