package ttn.com.execute;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import ttn.com.domains.Restaurant;

public class Question9 {

    public static void main(String[] args) {
        ApplicationContext applicationContext=new ClassPathXmlApplicationContext("Question9SpringConfig.xml");
        Restaurant restaurant=(Restaurant) applicationContext.getBean(Restaurant.class);
        restaurant.getHotDrink().prepareHotDrink();

    }
}
