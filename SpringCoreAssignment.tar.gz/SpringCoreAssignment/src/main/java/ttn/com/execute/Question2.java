package ttn.com.execute;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import ttn.com.domains.Database;


public class Question2 {

    public static void main(String[] args) {

        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("springConfig.xml");
        Database obj = applicationContext.getBean(Database.class);
        System.out.println("Name:"+obj.getName());
        System.out.println("Port:"+obj.getPort());
    }

}
