package ttn.com.execute;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import ttn.com.domains.Restaurant;

public class Question7 {
    public static void main(String[] args) {


        ApplicationContext applicationContext=new ClassPathXmlApplicationContext("Question7SpringConfig.xml");
        System.out.println(applicationContext.isPrototype("teaRestaurant"));
    }
}
