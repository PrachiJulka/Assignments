package ttn.com.execute;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import ttn.com.domains.Restaurant;

public class Question6 {

    public static void main(String[] args) {
        ApplicationContext applicationContext=new ClassPathXmlApplicationContext("Question6SpringConfig.xml");
        Restaurant restaurant=applicationContext.getBean("restaurant", Restaurant.class);
        restaurant.getHotDrink().prepareHotDrink();


    }
}
