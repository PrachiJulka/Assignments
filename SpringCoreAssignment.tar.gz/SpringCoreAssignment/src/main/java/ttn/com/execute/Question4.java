package ttn.com.execute;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import ttn.com.domains.Restaurant;

public class Question4 {

    public static void main(String[] args) {
        ApplicationContext applicationContext=new ClassPathXmlApplicationContext("Question4SpringConfig.xml");
        Restaurant restaurantExpress=applicationContext.getBean("expressTeaRestaurantInner",Restaurant.class);
        Restaurant restaurantTea=applicationContext.getBean("tearestaurant",Restaurant.class);
        restaurantExpress.getHotDrink().prepareHotDrink();
        restaurantTea.getHotDrink().prepareHotDrink();
    }
}
