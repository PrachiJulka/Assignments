package ttn.com.domains;

public interface HotDrink {
    void prepareHotDrink();
}
