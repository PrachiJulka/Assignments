package ttn.com.domains;

public class ExpressTea /* For Question9 implements HotDrink */{

    /*@Override
    public void prepareHotDrink() {
        System.out.println("Express Tea is prepared");
    }
*/}
