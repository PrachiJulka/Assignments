package ttn.com.domains;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Required;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;


/* For Question9 and Question10
@Component
*//*
* for Question10
@Controller*/
/* for Question 10
@Repository*/
public class Restaurant {

    /* for Q9 by Field
    @Autowired
    @Qualifier("tea")*/
    private HotDrink hotDrink;


  /* for Question6
  Restaurant(HotDrink hotDrink){
        this.hotDrink=hotDrink;
    }*/
 /* for Q9 by Constructor
  @Autowired
  Restaurant(HotDrink hotDrink){
      this.hotDrink=hotDrink;
  }*/
    public HotDrink getHotDrink() {
        return hotDrink;
    }

    @Override
    public String toString() {
        return "Restaurant{" +
                "hotDrink=" + hotDrink +
                '}';
    }

    /* for Question8 @Required*/
   /* for Question9 using setter @Autowired
*/    public void setHotDrink(HotDrink hotDrink) {
        this.hotDrink = hotDrink;
    }

}
