package ttn.com.domains;


import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
/*
for Question 10 and 9
@Component
@Repository
@Service
@Controller*/
public class Tea implements HotDrink {

    @Override
    public void prepareHotDrink() {
        System.out.println("Tea Drink is Prepared");
    }
}
