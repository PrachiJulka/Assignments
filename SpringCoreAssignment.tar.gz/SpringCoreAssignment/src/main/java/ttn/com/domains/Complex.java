package ttn.com.domains;

/*
    Create Class Complex as follows: class complex {    List list;

    Set set;

    Map map;

} Initialize all the instance variables of the complex class using Spring XML. Give bean name as

        complexBean. Get the bean and display the properties*/


import java.util.List;
import java.util.Map;
import java.util.Set;

public class Complex {

List<Integer> list;
Set<Integer> set;
Map<String,String> map;

    public List<Integer> getList() {
        return list;
    }

    public void setList(List<Integer> list) {
        this.list = list;
    }

    public Set<Integer> getSet() {
        return set;
    }

    public void setSet(Set<Integer> set) {
        this.set = set;
    }

    public Map<String, String> getMap() {
        return map;
    }

    public void setMap(Map<String, String> map) {
        this.map = map;
    }
}
