package com.ttn.questions;

import java.io.IOException;

public class Q1 {
    public static void main(String[] args) throws IOException, Exception {

        //========================JSON===================================
        byte[] jsonData = Files.readAllBytes(Paths.get("Employees.json"));
        ObjectMapper objectMapper = new ObjectMapper();
        ObjectWriter writer = objectMapper.writer(new DefaultPrettyPrinter());
        JsonNode rootNode = objectMapper.readTree(jsonData);
        writer.writeValue(new File("C:/Users/Prashant/Documents/test.txt"), rootNode);

        System.out.println("Employees\n" + rootNode);
        for (JsonNode curr : rootNode) {
            JsonNode idNode = curr.findParent("id");
            Iterator<JsonNode> elementsid = idNode.getElements();
            while (elementsid.hasNext()) {
                JsonNode e = elementsid.next();
                System.out.println(e.toString());
            }
            System.out.println("*********************************************");
        }

        //============================XML DOM PARSER=================================
        System.out.println("\n XML DOM PARSER EXAMPLE");
        File inputFile = new File("Employees.xml");
        DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
        DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
        Document doc = docBuilder.parse(inputFile);
        Node emp = doc.getFirstChild();

        doc.getDocumentElement().normalize();

        System.out.println("Root element :" + doc.getDocumentElement().getNodeName());

        NodeList nList = doc.getElementsByTagName("employee");

        for (int temp = 0; temp < nList.getLength(); temp++) {

            Node nNode = nList.item(temp);
            System.out.println("\nCurrent Element :"
                    + nNode.getNodeName());
            if (nNode.getNodeType() == Node.ELEMENT_NODE) {

                Element eElement = (Element) nNode;

                System.out.println("Staff id : " + eElement.getAttribute("id"));
                System.out.println("First Name : " + eElement.getElementsByTagName("firstName").item(0).getTextContent());
                System.out.println("Last Name : " + eElement.getElementsByTagName("lastName").item(0).getTextContent());
                System.out.println("Gender : " + eElement.getElementsByTagName("gender").item(0).getTextContent());
                System.out.println("Age : " + eElement.getElementsByTagName("age").item(0).getTextContent());
                System.out.println("Location : " + eElement.getElementsByTagName("location").item(0).getTextContent());

            }
        }

        // write the content into xml file
        TransformerFactory transformerFactory = TransformerFactory.newInstance();
        Transformer transformer = transformerFactory.newTransformer();
        DOMSource source = new DOMSource(doc);
        StreamResult result = new StreamResult(new File("C:/Users/Prashant/Documents/test1.txt"));
        transformer.transform(source, result);

        System.out.println("***************************************************");

        //===========================XML SAX PARSER=============================
        System.out.println("\n XML SAX PARSER EXAMPLE");
        SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
        SAXParser saxParser = saxParserFactory.newSAXParser();
        MyHandler handler = new MyHandler();
        saxParser.parse(new File("Employees.xml"),
                handler);
        //Printing the list of employees obtained from XML
        for (Employee empl : handler.empList){
            System.out.println(empl);
        }

    }

}
