//is palindrome string


function passValue(){

var str=document.getElementById("str").value;

var end=str.length-1;
       
        var start=0;
       var result=palindrome(start,str,end);
       if(result==1){
        alert("Not Palindrome");
           
       }
       else{
        alert("Palindrome");
       }
	}

function palindrome(start,str,end){
          if(start>end)
            {
                return 0;
            }
            else{
                if(str.charAt(start)==str.charAt(end)){
                    return(palindrome(++start,str,--end));
                }
                else{
                    return 1;
                }
            }
        }