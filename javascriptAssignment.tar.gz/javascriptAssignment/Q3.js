//Area of circle
function areaOfCircle(){
	var r=document.getElementById("radius").value;
	var area=((3.17 * r) * r);
	alert(area);
}