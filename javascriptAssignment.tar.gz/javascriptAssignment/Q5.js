/*create a list of objects of Employee with info as follow :

    Name, age, salary ,DOB

    filter all employees with salary greater than 5000

    group employee on the basis of their age
   
   fetch employees with salary less than 1000 and age greater than 20. Then give them an increment 5 times their salary.
*/

//array
var empArr=[];

// Initialisation of objects 
function init(){
	var employeeObj1=new Object;
	var employeeObj2=new Object;
	var employeeObj3=new Object;
	var employeeObj4=new Object;
	var employeeObj5=new Object;

	employeeObj1.name="jimmy";
    employeeObj1.age=20;
    employeeObj1.salary=10000;
    employeeObj1.dob="12/08/1993";
    employeeObj1.flag=true;

    employeeObj2.name="Joey";
    employeeObj2.age=22;
    employeeObj2.salary=900;
    employeeObj2.dob="12/09/1993";
    employeeObj2.flag=true;

    employeeObj3.name="Ross";
    employeeObj3.age=25;
    employeeObj3.salary=3000;
    employeeObj3.dob="10/08/1993";
    employeeObj3.flag=true;

    employeeObj4.name="Rachel";
    employeeObj4.age=20;
    employeeObj4.salary=8000;
    employeeObj4.dob="12/04/1992";
    employeeObj4.flag=true;

    employeeObj5.name="monica";
    employeeObj5.age=22;
    employeeObj5.salary=5000;
    employeeObj5.dob="24/08/1993";
    employeeObj5.flag=true;

    empArr.push(employeeObj1);
    empArr.push(employeeObj2);
    empArr.push(employeeObj3);
    empArr.push(employeeObj4);
    empArr.push(employeeObj5);
}




//filter all employees with salary greater than 5000
function filterEmpSal(){
	init();
	
	var lb = document.getElementById("tbl");
	for(i in empArr){
		if(empArr[i].salary > 5000){
			var liName=document.createElement('td');
			var liAge=document.createElement('td');
			var liSalary=document.createElement('td');
			var liDob=document.createElement('td');
			var liEmpty=document.createElement('td');
			lb.innerHTML+="<tr>"
			liName.innerText=empArr[i].name;
			liAge.innerText=empArr[i].age;
			liSalary.innerText=empArr[i].salary;
			liDob.innerText=empArr[i].dob;
			liEmpty.innerText='';
			lb.append(liName);
			lb.append(liAge);
			lb.append(liSalary);
			lb.append(liDob);
			lb.append(liEmpty);
			lb.innerHTML+="</tr>"
						
		}
	}	
}

//group employee on the basis of their age

function groupEmpAge(){
	init();
	for(i in empArr){
		var temp=[];
		if(empArr[i].flag==true)
		{
			var age=empArr[i].age;
			temp.push(empArr[i].name);
			empArr[i].flag=false;
			for(j in empArr){
				if(age==empArr[j].age && empArr[j].flag==true)
				{
					temp.push(empArr[j].name);
					empArr[j].flag=false;
				}
			}
			var lb = document.getElementById("tb2Body");
			
			for(k of temp)
			{
				
				var row=document.createElement('tr');
				var liName=document.createElement('td');
				var liAge=document.createElement('td');
				liName.innerText=k;
				liAge.innerText=age;
				row.append(liName);
				row.append(liAge);
				lb.append(row)
				
			}
			var row=document.createElement('tr');
			var empty=document.createElement('td');
				row.append(empty);
				lb.append(row)
				
			
		}
	}
}

//   fetch employees with salary less than 1000 and age greater than 20. Then give them an increment 5 times their salary.

function incrementSalary(){
	init();
	for(i in empArr){
		if(empArr[i].salary<1000 &&  empArr[i].age>20){
		
			var sal=empArr[i].salary;
			empArr[i].salary *= 5;
						empArr[i].salary+=sal;
		
		}
	}
	var lb = document.getElementById("tbl3");
	
	
	for(i in empArr){
		
		
	var liName=document.createElement('td');
			var liAge=document.createElement('td');
			var liSalary=document.createElement('td');
			var liDob=document.createElement('td');
			var liEmpty=document.createElement('td');
			lb.innerHTML+="<tr>"
			liName.innerText=empArr[i].name;
			liAge.innerText=empArr[i].age;
			liSalary.innerText=empArr[i].salary;
			liDob.innerText=empArr[i].dob;
			liEmpty.innerText='';
			lb.append(liName);
			lb.append(liAge);
			lb.append(liSalary);
			lb.append(liDob);
			lb.append(liEmpty);	
			lb.innerHTML+="</tr>"
	}

}












