//Copy information of one object to another and log it to console.
function copyObj(){
var obj = new Object
obj.name='prachi'
obj.age=23

var obj2 = new Object

for(i in obj)
{
    obj2[i]=obj[i]
}
console.log("object 1 name"+obj.name);
console.log("object 2 name"+obj2.name);
obj.name='New Name'

console.log("object 1 name after change"+obj.name);
console.log("object 2 name"+obj2.name);


}



