// function to calculate Simple Interest.
function simpleInterest(){
	var amount=prompt("Enter amount");
	var rs=prompt("Enter rate of interest");
	var year=prompt("Enter number of years");
	var SI=amount * rs * year;
	alert(SI);
}