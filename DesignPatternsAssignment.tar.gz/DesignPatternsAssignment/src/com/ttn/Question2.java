package com.ttn;

import java.util.List;
import java.util.ArrayList;

/*
Suppose we are building a cricket app that notifies viewers about the information such as current
score, run rate etc. Suppose we have made two display elements CurrentScoreDisplay and AverageScoreDisplay.
CricketData has all the data (runs, bowls etc.) and whenever data changes the display elements are
notified with new data and they display the latest data accordingly.*/

public class Question2 {

    public static void main(String[] args) {
        CricketData cricketData=new CricketData();
        CurrentScoreDisplay currentScoreDisplay=new CurrentScoreDisplay(cricketData);
        AverageScoreDisplay averageScoreDisplay=new AverageScoreDisplay(cricketData);
        cricketData.setData(376,300);
        cricketData.setData(100,200);
    }
}




 interface Subject {
    public void registerObserver(Observer observer);
    public void removeObserver(Observer observer);
    public void notifyObserver();
}

 interface Observer {
    public void update(int runs,int bowls);
}


class CricketData implements Subject {
    private int runs;
    private int bowls;

    private List<Observer> observers = new ArrayList<>();

    @Override
    public void registerObserver(Observer observer) {
        observers.add(observer);
    }

    @Override
    public void removeObserver(Observer observer) {
        int i = observers.indexOf(observer);
        if (i >= 0)
            observers.remove(observer);
    }

    @Override
    public void notifyObserver() {
        for (int i = 0; i < observers.size(); i++) {
            observers.get(i).update(runs, bowls);
        }
    }

    public void dataChanged() {
        notifyObserver();
    }

    public void setData(int runs, int bowls) {
        setBowls(bowls);
        setRuns(runs);
        dataChanged();
    }

    public int getRuns() {
        return runs;
    }

    public void setRuns(int runs) {
        this.runs = runs;
    }

    public int getBowls() {
        return bowls;
    }

    public void setBowls(int bowls) {
        this.bowls = bowls;
    }
}

class CurrentScoreDisplay implements Observer{

    Subject subject;

    public CurrentScoreDisplay(Subject subject) {
        this.subject = subject;
        subject.registerObserver(this);
    }

    @Override
    public void update(int runs, int bowls ) {
        System.out.println("-------------- C U R R E N T   S C O R E -----------");
        System.out.println("Runs : "+runs);
        System.out.println("Bowls : "+bowls);

    }
}


class AverageScoreDisplay implements Observer{
    Subject subject;

    public AverageScoreDisplay(Subject subject) {
        this.subject = subject;
        subject.registerObserver(this);
    }

    @Override
    public void update(int runs, int bowls) {
        System.out.println("-------- A V E R A G E    S C O R E    D I S P L A Y --------");
        float avg=(float) runs/bowls;
        System.out.println("Average runs : "+avg);
    }
}