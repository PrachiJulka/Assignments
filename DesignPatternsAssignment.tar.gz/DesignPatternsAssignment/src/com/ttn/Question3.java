package com.ttn;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

/*
Suppose we are building a utility, where multiple threads are doing some calculations
and they use large values read from a file by a file reader class (there is a single
file that has multiple values and each thread will be working on exactly one value).
The file reader class should be optimized for performance and resource utilization
along with thread safety so that no two threads are working on the same value.*/
public class Question3 {
    public static void main(String[] args) {

        SingletonFileReader singletonFileReader=SingletonFileReader.getInstance();
        try {
            singletonFileReader.readingFile();
        } catch (IOException e) {
            e.printStackTrace();
        }
        System.out.println("---------Fetching values---------");
        singletonFileReader.fetchingValues();
        System.out.println("---------------------------------");
        Thread t=new Thread(Question3::thread1Method);
        Thread t1=new Thread(Question3::thread2Method);

        System.out.println("Thread execution (2 threads on same value) : ");
        t.start();
        t1.start();

    }


    static void thread1Method(){
        SingletonFileReader singletonFileReader=SingletonFileReader.getInstance();
        Integer val=singletonFileReader.getValue(0);

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println(val);

    }
    static void thread2Method(){
        SingletonFileReader singletonFileReader=SingletonFileReader.getInstance();
        Integer val=singletonFileReader.getValue(0);

        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        System.out.println(val);

    }
}



class SingletonFileReader{

    private static SingletonFileReader onlyObject=new SingletonFileReader();
    private ArrayList<Integer> values=new ArrayList<>();

    private SingletonFileReader()  {
    }

    public static SingletonFileReader getInstance(){
        return onlyObject;
    }

    public void readingFile() throws IOException {
        FileReader fileReader = new FileReader("/home/prachi/Demo.txt");
        BufferedReader bufferedReader = new BufferedReader(fileReader);
        String sCurrentLine;
        bufferedReader = new BufferedReader(fileReader);
        while ((sCurrentLine = bufferedReader.readLine()) != null) {
//            System.onut.println(sCurrentLine);
            values.add(Integer.parseInt(sCurrentLine));
        }
    }

    public synchronized void fetchingValues(){
        for (int i = 0; i < values.size(); i++) {
            System.out.println(values.get(i));
        }
    }

    public synchronized Integer getValue(int i){
        if (i>=0)
            return values.get(i);
        else
            return -1;
    }

}
