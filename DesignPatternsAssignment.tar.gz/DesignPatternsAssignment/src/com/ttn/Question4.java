package com.ttn;

public class Question4 {
    public static void main(String[] args) {
        Pikachu pikachu=new Pikachu();

        System.out.println("--------------Pikachu--------------");
        pikachu.jump();
        pikachu.roll();
        pikachu.punch();
        pikachu.kick();

        System.out.println("--------------JigglyPuff------------");
        JigglyPuff jigglyPuff=new JigglyPuff();
        jigglyPuff.jump();
        jigglyPuff.roll();
        jigglyPuff.kick();
        jigglyPuff.punch();
    }
}


abstract class Fighter{
    RollBehaviour rollBehaviour;
    JumpBehaviour jumpBehaviour;
    public void kick(){
        System.out.println("Fighter is kicking.");
    }
    public void punch(){
        System.out.println("Fighter punches.");
    }
    public void jump(){
        jumpBehaviour.jump();
    }
    public void roll(){
        rollBehaviour.roll();
    }

    public abstract void setJumpBehaviour();

    public abstract void setRollBehaviour();
}
interface RollBehaviour{
    public void roll();
}

class SpeedyRoll implements RollBehaviour{
    @Override
    public void roll() {
        System.out.println("This is SpeedyRoll");
    }
}

class SteadyRoll implements RollBehaviour{
    @Override
    public void roll() {
        System.out.println("This is SteadyRoll");
    }
}

interface JumpBehaviour{
    public void jump();
}
class MonkeyJump implements JumpBehaviour{
    @Override
    public void jump() {
        System.out.println("This is Monkey Jump");
    }
}

class HumanJump implements JumpBehaviour{
    @Override
    public void jump() {
        System.out.println("This is Normal Jump");
    }
}

class Pikachu extends Fighter{

    public Pikachu() {
        setJumpBehaviour();
        setRollBehaviour();
    }
    @Override
    public void setJumpBehaviour() {
        this.jumpBehaviour=new MonkeyJump();
    }

    @Override
    public void setRollBehaviour() {
        this.rollBehaviour=new SpeedyRoll();
    }
}

class JigglyPuff extends Fighter{
    public JigglyPuff(){
        setJumpBehaviour();
        setRollBehaviour();
    }
    @Override
    public void setJumpBehaviour() {
        this.jumpBehaviour=new HumanJump();
    }

    @Override
    public void setRollBehaviour() {
        this.rollBehaviour=new SteadyRoll();

    }
}


