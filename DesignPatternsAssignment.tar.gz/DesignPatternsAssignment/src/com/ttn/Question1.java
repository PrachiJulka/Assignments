package com.ttn;
/*

Suppose we are building an application for a pizza store and we need
 to model their pizza classes.Assume they offer four types of pizzas
 namely Peppy Paneer,Farmhouse,Margherita and Chicken Fiesta.In addition
  to a pizza,customer can also ask for several toppings such as Fresh
   Tomato,Paneer,Jalapeno,Capsicum,Barbeque,etc.
   Customer can choose pizza with toppings and we need to get the total
    cost of pizza and toppings the customer chooses.
*/


import java.util.ArrayList;
import java.util.List;

class Pizza{
    int price=0;


    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price=price;
    }
}

class PeppyPaneer extends Pizza{
    @Override
    public String toString() {
        return "PeppyPanner{" +
                "price=" + price +
                '}';
    }
}

class Farmhouse extends Pizza{
    @Override
    public String toString() {
        return "Farmhouse{" +
                "price=" + price +
                '}';
    }
}

class Margherita extends Pizza{

    @Override
    public String toString() {
        return "Margherita{" +
                "price=" + price +
                '}';
    }
}


class ChickenFiesta extends Pizza{
    @Override
    public String toString() {
        return "ChickenFiesta{" +
                "price=" + price +
                '}';
    }
}

abstract class PizzaToppings {

    int price;

    public Pizza addTopping(Pizza pizza){
        pizza.setPrice(pizza.getPrice()+this.price);
        return pizza;
    }
    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price=price;
    }

    public abstract void setPrice();
}

class Paneer extends PizzaToppings {

    public void setPrice(){setPrice(120);}

    @Override
    public String toString() {
        return "Paneer price= Rs." + price;
    }
}

class Jalapenos extends PizzaToppings {

    public void setPrice(){setPrice(50);}

    @Override
    public String toString() {
        return "Jalapenos price= Rs." + price;
    }
}

class Barbeque extends PizzaToppings {

    public void setPrice(){setPrice(200);}

    @Override
    public String toString() {
        return "Barbeque price= Rs." + price;
    }
}

class Capsicum extends PizzaToppings {

    public void setPrice(){setPrice(200);}

    @Override
    public String toString() {
        return "Capsicum price= Rs." + price;
    }
}


public class Question1 {

    public static void main(String[] args) {

//      Creating toppings
        PizzaToppings barbeque=new Barbeque();
        PizzaToppings jalapenos=new Jalapenos();
        PizzaToppings paneer=new Paneer();
        PizzaToppings capsicum=new Capsicum();

        List<PizzaToppings> pizzaToppings=new ArrayList<>();
        pizzaToppings.add(barbeque);
        pizzaToppings.add(jalapenos);
        pizzaToppings.add(paneer);
        pizzaToppings.add(capsicum);

//      Setting price of each topping
        for(int i=0;i<pizzaToppings.size();i++){
            PizzaToppings toppings=pizzaToppings.get(i);
            toppings.setPrice();
        }


//      Toppings menu
        System.out.println("------ T O P P I N G S ------");
        for(int i=0;i<pizzaToppings.size();i++) {
            PizzaToppings toppings = pizzaToppings.get(i);
            System.out.println(toppings);
        }


        System.out.println("********* B I L L *********");
        System.out.println("Ordering peppy paneer ...");
        Pizza pizza=new PeppyPaneer();
        pizza.setPrice(300);
        System.out.println("Base price : "+pizza.getPrice());

        System.out.println("Adding barbeque topping ...");
        barbeque.addTopping(pizza);
        System.out.println("Total price : "+pizza.getPrice());

        System.out.println("Adding paneer topping ...");
        paneer.addTopping(pizza);
        System.out.println("Total price : "+pizza.getPrice());


        System.out.println("Adding Capsicum" +
                " topping ...");
        capsicum.addTopping(pizza);
        System.out.println("Total price : "+pizza.getPrice());

    }

}



