
$(document).ready(function() {

loadData();

});


function loadData(){
    $.ajax({
        type: "GET",
        url: "/blog",
        success: function (response) {

            renderTable(response);
        },
        error: function (e) {
            alert("ERROR");
        }
    });
}





function renderTable(data) {

    $("#ResultArea").html("");

    var table = $("<table id=DisplayData class='table table-hover' width='100%' cellspacing='0'></table>").appendTo("#ResultArea");

    var rowHeader = $("<tr style='background-color: #757575'></tr>").appendTo(table);
    $("<th></th>").text("Blog Id").appendTo(rowHeader);
    $("<th></th>").text("Blog Description").appendTo(rowHeader);

    $.each(data, function (i, value) {

        var row = $("<tr> </tr>").appendTo(table);
        $("<td></td>").text(value.blogId).appendTo(row);
        $("<td></td>").text(value.blogContent).appendTo(row);
    });
}
    function addBlog() {
        var blogDescription=$('#blogDescription').val();

        $.ajax({
            type: "POST",
            url: "/blog",
            data:"blogDescription= " + blogDescription,

            success: function (response) {
                alert("Added Success");
                loadData();
            }
            ,
            error: function (e) {
                alert("ERROR");
            }
        });
    }