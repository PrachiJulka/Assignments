package com.ttn.dao.impl;

import com.ttn.dao.UserDao;
import com.ttn.domains.User;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import javax.persistence.Query;
import java.util.List;

public class UserDaoImplementation implements UserDao {

    private static Query query;
    private SessionFactory sessionFactory=new Configuration().
            configure("hibernate.cfg.xml").buildSessionFactory();

    @Override
    public String addUser(String email,String userName,String password){
        String msg;
        Session session=sessionFactory.openSession();
        session.beginTransaction();
        if(validateEmail(email)==true) {
            User user = new User();
            user.setUserName(userName);
            user.setEmail(email);
            user.setPassword(password);
            session.save(user);
            msg="Registered";
        }
        else {
            msg="Email name Already exists";
        }

        session.getTransaction().commit();
        session.close();


        return msg;
    }


    @Override
    public boolean validateEmail(String email){
        Session session=sessionFactory.openSession();
        session.beginTransaction();
        query= session.createQuery(" from User where email=?");
       query.setParameter(0,email);
        List list = query.getResultList();
        if(list.size()>0 && list!=null)
            return false;

        else{
            session.getTransaction().commit();
            session.close();
           return true;
        }

    }

    @Override
    public User validateUser(String email, String password) {
        User user=null;
        Session session=sessionFactory.openSession();
        session.beginTransaction();
        query=session.createQuery("from User where email=? AND password=?");
        query.setParameter(0,email);
        query.setParameter(1,password);
        try {
            user = (User) query.getSingleResult();
        }
        finally {

            session.getTransaction().commit();
            session.close();
            return user;
        }

    }
}
