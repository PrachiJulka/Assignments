package com.ttn.dao;

import com.ttn.domains.Blog;
import com.ttn.domains.User;

import java.util.List;

public interface BlogDao {

     String addBlog(String blogDescription,User user);
     List<Blog> getBlogs(User user);
}
