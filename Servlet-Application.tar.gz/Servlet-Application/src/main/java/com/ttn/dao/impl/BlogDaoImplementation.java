package com.ttn.dao.impl;

import com.ttn.dao.BlogDao;

import com.ttn.domains.Blog;
import com.ttn.domains.User;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import javax.persistence.Query;
import java.util.List;

public class BlogDaoImplementation implements BlogDao {
    private static Query query;

    private SessionFactory sessionFactory=new Configuration().
            configure("hibernate.cfg.xml").buildSessionFactory();

    @Override
    public String addBlog(String blogDescription,User user) {
        String msg;

        System.out.println("blog"+blogDescription);
        Session session=sessionFactory.openSession();
        session.beginTransaction();
            Blog blog= new Blog();
            blog.setBlogContent(blogDescription);
            blog.setUser(user);
            session.save(blog);
            msg="Blog Added Successfully";
        session.getTransaction().commit();
        session.close();
         return msg;
    }

    @Override
    public List<Blog> getBlogs(User user){
        List<Blog> list=null;
        Session session=sessionFactory.openSession();
        session.beginTransaction();
        query=session.createQuery("from Blog where user.userId=?");
        query.setParameter(0,user.getUserId());
        try {
             list = query.getResultList();
            }
        finally {
            session.getTransaction().commit();
            session.close();
            return list;
        }
    }
}
