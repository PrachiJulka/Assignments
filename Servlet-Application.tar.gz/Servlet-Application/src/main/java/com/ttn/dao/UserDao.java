package com.ttn.dao;

import com.ttn.domains.User;

public interface UserDao {

     String addUser(String email,String userName,String password);
    boolean validateEmail(String email);
    User validateUser(String email, String password);
}
