package com.ttn.servlets;

import com.google.gson.Gson;
import com.ttn.dao.impl.BlogDaoImplementation;
import com.ttn.dao.impl.UserDaoImplementation;
import com.ttn.domains.Blog;
import com.ttn.domains.User;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.List;

@WebServlet(name = "ServletBlog",urlPatterns = "/blog")
public class ServletBlog extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
        response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
        response.setDateHeader("Expires", 0);

        String blogDescription = request.getParameter("blogDescription");
        HttpSession httpSession = request.getSession(false);
        User user = (User) httpSession.getAttribute("user");
        String button = request.getParameter("btn");
        if (user!= null) {
           if (button==null) {
              new BlogDaoImplementation().addBlog(blogDescription, user);
            }
            else if(button.equals("logOut")) {
               httpSession.invalidate();
               response.sendRedirect("index.jsp");
              }
         }
        else{
            response.sendRedirect("index.jsp");
        }
    }
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession httpSession = request.getSession(false);
        User user = (User) httpSession.getAttribute("user");
        List<Blog> blog=new BlogDaoImplementation().getBlogs(user);
        String json = new Gson().toJson(blog);

        response.setContentType("application/json");

        response.setCharacterEncoding("UTF-8");

        response.getWriter().write(json);

        }

    }
