package com.ttn.servlets;

import com.ttn.dao.impl.UserDaoImplementation;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


@WebServlet(name = "ServletRegistration",urlPatterns = "/registration")
public class ServletRegistration extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        String email=request.getParameter("email");
        String userName=request.getParameter("userName");
        String password=request.getParameter("registrationPassword");
        String msg= new UserDaoImplementation().addUser(email,userName,password);
        response.sendRedirect("/?msg="+msg);
    }



}
