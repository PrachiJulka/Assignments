
$(document).ready(function(){
	$('a').click(function(event){
 var result=prompt("Enter yes to Continue");
   if(result=='no' || result=='NO'){
	event.preventDefault();
   }
   });  
});

	