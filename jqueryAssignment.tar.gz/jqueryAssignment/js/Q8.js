//Click event not working on element which added dynamicly or via script, make it work using .on method

$(document).ready(function(){

var el = $("<button>next</button>").attr({
	id:"btn1"
	});
$("#test1").after(el);

$("#btn1").on("click", function(e) {
alert("hello");
});
});
