$(document).ready(function(){
$("#test").attr("class", "body");
});

