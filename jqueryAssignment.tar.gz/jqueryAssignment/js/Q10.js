$(document).ready(function() {
 $(".sub").hide();
	$("#menu").hover(
	function() { $(".sub").slideToggle(400); },
	function() { $(".sub").hide(); }
	);
	});  
		