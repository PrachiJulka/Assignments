$(document).ready(function(){
$("button").click(function(){
$("#main > .target").css('font-size','20px');
});
});
