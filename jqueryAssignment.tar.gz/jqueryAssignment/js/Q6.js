$(document).ready(function(){
$("button").click(function(){
$("#span").unwrap();
var el = $("<p>I am a Paragraph</p>", {
});
$("#main").html(el);

});
});
