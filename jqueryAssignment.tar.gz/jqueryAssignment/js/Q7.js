//Bind a click function to an "click" element and append next "click" next to it.

$(document).ready(function(){
$("button").click(function(){
var el = $("<button>next</button>").attr({
	id:"btn1"
	});
$("#btn").after(el);

$("#btn1").on("click", function(e) {
alert("hello");

});



});
});
