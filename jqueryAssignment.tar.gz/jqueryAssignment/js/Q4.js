
$(document).ready(function(){

$("input[type=submit]").attr('disabled','disabled');
});

	