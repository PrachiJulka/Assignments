$(document).ready(function(){

$("button").click(function(){

$("[class$=-new]").css("background-color","pink");

});
});

