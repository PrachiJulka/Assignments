$(document).ready(function(){
	$('.s_btn').click(function(){
		if($('.s_input').val()>10)
			{$('#s_add').append('<tr><td style="background:red;">'+$('.s_input').val()+'</td></tr>');}
		else
		{
			$('#s_add').append('<tr><td>'+$('.s_input').val()+'</td></tr>');
		}
	});
});