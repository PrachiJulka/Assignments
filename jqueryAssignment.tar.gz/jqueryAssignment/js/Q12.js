//We have bind a click funtion to parent div but we want stop it from performing when user clicks on its child li

$(document).ready(function() {
$('#main').click(function(){
alert('parent div');
});
$("#main li").click(function(e) {
        $("#main").off("click");
   });
})

	