
$(document).ready(function(){

$("button").click(function(){
$.ajax({url:"https://code.jquery.com/jquery-3.2.1.min.js", async:false, success:function(result){
$("div").html(result);
}});
});
});