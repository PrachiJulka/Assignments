//Get the max height of elements using jquery each method

$(document).ready(function(){
  $(".main").each(function( i ) {
	var height=$(this).css('max-height');
    var el = $("<td>"+height+"</td>", {
	
	});
$("#tr").append(el);    
});
});
