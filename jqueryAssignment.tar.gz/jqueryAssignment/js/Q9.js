//Get dropdown selected value on onchanage event and append in div container
$(document).ready(function(){

$("#collg").on("change", function(e) {
var val=$('#collg').val();

$("div").append('<br/>'+val);

});
});
